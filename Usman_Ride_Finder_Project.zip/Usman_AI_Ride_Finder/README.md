# Usman AI Ride Finder — Android starter project

This is source code, not an already-built APK.

## Features
- Editable minimum fare (default Rs. 370).
- Editable maximum displayed trip distance (default 15 km).
- Attempts to read visible ride-request text through Android Accessibility.
- Shows a popup with fare, distance and estimated fare per km.
- Does not auto-accept rides, tap buttons, book rides or bypass inDrive controls.

## Limitations and safety
- The text reader may need adjustment for the exact inDrive app version and language.
- Accessibility and overlay permissions must be enabled manually by the phone owner.
- Accessibility permission is powerful; enable it only for software you trust.
- This project processes visible text locally and does not upload it.
- Use only while safely parked. Never interact with the phone while driving.
- Compatibility with inDrive and its terms is not guaranteed.

## Build
Open in Android Studio and run `app` > `assembleDebug`.
The APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included to build a debug APK when pushed to `main`.
