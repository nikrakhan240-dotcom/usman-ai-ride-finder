package com.usman.ridefinder;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    EditText minFare, maxPickup;
    TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF172554);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1); root.setPadding(28,40,28,28);
        root.setBackgroundColor(0xFFF8FAFC);
        TextView title = new TextView(this);
        title.setText("USMAN AI RIDE FINDER");
        title.setTextSize(23); title.setTextColor(0xFF172554);
        title.setGravity(Gravity.CENTER); title.setPadding(0,0,0,20);
        root.addView(title);
        TextView info = new TextView(this);
        info.setText("Ride alerts ko filter karein. App sirf inDrive ki phone notifications par kaam karta hai; ride list ko khud scan ya accept nahi karta.");
        info.setTextSize(16); info.setTextColor(0xFF334155); info.setPadding(0,0,0,20);
        root.addView(info);
        root.addView(label("Minimum fare (Rs.)"));
        minFare = field("370"); root.addView(minFare);
        root.addView(label("Maximum pickup distance (km)"));
        maxPickup = field("15"); root.addView(maxPickup);
        Button save = new Button(this); save.setText("Save filters");
        root.addView(save);
        Button access = new Button(this); access.setText("Enable notification access");
        root.addView(access);
        status = new TextView(this); status.setText("Status: notification access zaroori hai.");
        status.setTextSize(14); status.setPadding(0,20,0,0); root.addView(status);
        setContentView(root);
        save.setOnClickListener(v -> {
            getSharedPreferences("filters",0).edit()
                .putInt("minFare", parse(minFare.getText().toString(),370))
                .putFloat("maxPickup", parseFloat(maxPickup.getText().toString(),15f)).apply();
            status.setText("Filters saved: Rs. " + parse(minFare.getText().toString(),370)
                + " minimum, " + parseFloat(maxPickup.getText().toString(),15f) + " km pickup maximum.");
        });
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        createChannel();
    }
    TextView label(String s) { TextView t=new TextView(this); t.setText(s); t.setTextSize(16); t.setTextColor(0xFF0F172A); t.setPadding(0,12,0,4); return t; }
    EditText field(String s) { EditText e=new EditText(this); e.setSingleLine(true); e.setText(s); e.setInputType(8194); return e; }
    int parse(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}
    float parseFloat(String s,float d){try{return Float.parseFloat(s.trim());}catch(Exception e){return d;}}
    void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("good_rides","Good ride alerts",NotificationManager.IMPORTANCE_HIGH);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
}
