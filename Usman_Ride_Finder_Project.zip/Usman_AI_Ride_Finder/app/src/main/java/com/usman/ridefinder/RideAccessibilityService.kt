package com.usman.ridefinder

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import java.util.Locale

class RideAccessibilityService : AccessibilityService() {
    private var overlay: TextView? = null
    private var lastShown = ""
    private val wm by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (!pkg.contains("indriver", true) && !pkg.contains("indrive", true)) return
        val text = StringBuilder()
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null) return
            node.text?.let { text.append(it).append(' ') }
            node.contentDescription?.let { text.append(it).append(' ') }
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(rootInActiveWindow)
        val screen = text.toString()
        val fare = Regex("""(?:Rs\.?|PKR)\s*([\d,]+)""", RegexOption.IGNORE_CASE)
            .find(screen)?.groupValues?.get(1)?.replace(",", "")?.toIntOrNull()
        val km = Regex("""(?:~\s*)?(\d+(?:\.\d+)?)\s*km""", RegexOption.IGNORE_CASE)
            .findAll(screen).lastOrNull()?.groupValues?.get(1)?.toFloatOrNull()
        if (fare == null || km == null || km <= 0f) return
        val prefs = getSharedPreferences("filters", MODE_PRIVATE)
        val minFare = prefs.getInt("min_fare", 370)
        val maxKm = prefs.getFloat("max_km", 15f)
        val rate = fare / km
        val good = fare >= minFare && km <= maxKm
        val message = if (good)
            "RIDE TO CHECK\nRs. $fare • ${String.format(Locale.US, "%.1f", km)} km\nRs. ${String.format(Locale.US, "%.0f", rate)}/km\nMeets your filters — review before accepting"
        else
            "LOW PRIORITY\nRs. $fare • ${String.format(Locale.US, "%.1f", km)} km\nRs. ${String.format(Locale.US, "%.0f", rate)}/km\nOutside your saved filters"
        if (message != lastShown) { lastShown = message; showOverlay(message, good) }
    }

    private fun showOverlay(message: String, good: Boolean) {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        if (overlay == null) {
            overlay = TextView(this).apply {
                textSize = 16f; setPadding(28, 22, 28, 22); setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xDD17324D.toInt())
            }
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                       else WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP; y = 90 }
            try { wm.addView(overlay, params) } catch (_: Exception) { overlay = null; return }
        }
        overlay?.text = message
        overlay?.setBackgroundColor(if (good) 0xDD176B3A.toInt() else 0xDD72511A.toInt())
        overlay?.postDelayed({
            overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            overlay = null
        }, 6500)
    }
    override fun onInterrupt() {}
    override fun onDestroy() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }
}
