package com.usman.ridefinder

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        root.addView(TextView(this).apply { text = "Usman AI Ride Finder"; textSize = 25f })
        root.addView(TextView(this).apply {
            text = "Ride suggestions for your Vivo phone\n\nDefault filters: minimum fare Rs. 370 and maximum trip distance 15 km."
            textSize = 16f; setPadding(0, 20, 0, 20)
        })
        val fare = EditText(this).apply { hint = "Minimum fare (Rs.)"; setText("370"); inputType = 2 }
        val distance = EditText(this).apply { hint = "Maximum trip distance (km)"; setText("15"); inputType = 8194 }
        root.addView(fare); root.addView(distance)
        root.addView(Button(this).apply {
            text = "Save filters"
            setOnClickListener {
                getSharedPreferences("filters", MODE_PRIVATE).edit()
                    .putInt("min_fare", fare.text.toString().toIntOrNull() ?: 370)
                    .putFloat("max_km", distance.text.toString().toFloatOrNull() ?: 15f).apply()
                Toast.makeText(this@MainActivity, "Filters saved", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Enable ride-screen reading"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Allow popup overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity))
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                else Toast.makeText(this@MainActivity, "Overlay permission already allowed", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(TextView(this).apply {
            text = "\nImportant: You must grant Accessibility and overlay permissions manually. The service reads visible screen text only. It never taps Accept, sends messages, or books rides. Compatibility depends on inDrive's screen layout."
            textSize = 13f
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
