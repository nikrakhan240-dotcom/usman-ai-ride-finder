package com.usman.ridefinder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Build;
import android.content.SharedPreferences;
import android.app.PendingIntent;
import android.content.Intent;
import java.util.regex.*;

public class RideNotificationListener extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName().toLowerCase();
        if (!pkg.contains("indrive")) return;
        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        String title = String.valueOf(n.extras.getCharSequence(Notification.EXTRA_TITLE, ""));
        String body = String.valueOf(n.extras.getCharSequence(Notification.EXTRA_TEXT, ""));
        String text = title + " " + body;
        int fare = firstInt(text, "(?:rs\\.?\\s*|pkr\\s*)([0-9,]+)");
        float km = firstFloat(text, "([0-9]+(?:\\.[0-9]+)?)\\s*km");
        SharedPreferences p = getSharedPreferences("filters",0);
        int minFare = p.getInt("minFare",370);
        float maxPickup = p.getFloat("maxPickup",15f);
        if (fare >= minFare && km >= 0 && km <= maxPickup) {
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel("good_rides")==null)
                nm.createNotificationChannel(new NotificationChannel("good_rides","Good ride alerts",NotificationManager.IMPORTANCE_HIGH));
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ?
                new Notification.Builder(this,"good_rides") : new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.ic_dialog_info)
             .setContentTitle("Possible good ride — Rs. " + fare)
             .setContentText("Pickup approx. " + km + " km. inDrive notification check karein.")
             .setAutoCancel(true);
            nm.notify((int)(System.currentTimeMillis()%100000), b.build());
        }
    }
    int firstInt(String s,String regex) {
        Matcher m=Pattern.compile(regex,Pattern.CASE_INSENSITIVE).matcher(s);
        if(m.find()) try{return Integer.parseInt(m.group(1).replace(",",""));}catch(Exception ignored){}
        return -1;
    }
    float firstFloat(String s,String regex) {
        Matcher m=Pattern.compile(regex,Pattern.CASE_INSENSITIVE).matcher(s);
        if(m.find()) try{return Float.parseFloat(m.group(1));}catch(Exception ignored){}
        return -1;
    }
}
